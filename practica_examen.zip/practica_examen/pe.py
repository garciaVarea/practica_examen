"""Crear estas clases
Define los atributos, métodos, constructores... que consideres
necesarios.

cursos:id,nombre, creditos, añosdeestudio
alumno:id, nombre, email
matricula:idmatricula, fechamatricula, idalumno, idcurso

Necesitamos.
mostrar la ficha del curso
mostrar la ficha de alumno
alumno1 se matricula en un curso
alumno2 se matricula en dos cursos
mostrar los datos de matrículo
reto*:método que muestra las mátriculas realizadas en mi centro"""


class Colores:
    RESET = "\033[0m"
    NEGRO, ROJO, VERDE, AMARILLO, AZUL, MAGENTA, CYAN, BLANCO = [
        f"\033[{i}m" for i in range(30, 38)
    ]


def print_color(texto, color):
    print(f"{color}{texto}{Colores.RESET}")


class Curso:
    def __init__(self, id, nombre, creditos, años_de_estudio):
        self.id = id
        self.nombre = nombre
        self.creditos = creditos
        self.años_de_estudio = años_de_estudio

    def mostrar_ficha(self):
        print_color(f"Ficha del Curso {self.nombre}:", Colores.AZUL)
        print_color(f"ID: {self.id}", Colores.AZUL)
        print_color(f"Créditos: {self.creditos}", Colores.AZUL)
        print_color(f"Años de estudio: {self.años_de_estudio}", Colores.AZUL)
        print()


class Alumno:
    def __init__(self, id, nombre, email):
        self.id = id
        self.nombre = nombre
        self.email = email

    def mostrar_ficha(self):
        print_color(f"Ficha del Alumno {self.nombre}:", Colores.VERDE)
        print_color(f"ID: {self.id}", Colores.VERDE)
        print_color(f"Email: {self.email}", Colores.VERDE)
        print()


class Matricula:
    def __init__(self, id_matricula, fecha_matricula, id_alumno, id_curso):
        self.id_matricula = id_matricula
        self.fecha_matricula = fecha_matricula
        self.id_alumno = id_alumno
        self.id_curso = id_curso

    def mostrar_datos(self):
        print_color("Datos de Matrícula:", Colores.AMARILLO)
        print_color(f"ID Matrícula: {self.id_matricula}", Colores.AMARILLO)
        print_color(f"Fecha de Matrícula: {self.fecha_matricula}", Colores.AMARILLO)
        print_color(f"ID Alumno: {self.id_alumno}", Colores.AMARILLO)
        print_color(f"ID Curso: {self.id_curso}", Colores.AMARILLO)
        print()


class CentroEstudios:
    def __init__(self):
        self.curso1 = Curso(1, "Programación en Python", 4, 2)
        self.curso2 = Curso(2, "Bases de Datos", 3, 1)
        self.alumno1 = Alumno(1, "Juan Pérez", "juan@email.com")
        self.alumno2 = Alumno(2, "Ana Gómez", "ana@email.com")
        self.matriculas = []

    def matricular_alumno(self, alumno, curso):
        id_matricula = len(self.matriculas) + 1
        fecha_matricula = "Fecha de Hoy"  # Puedes ajustar esto según tu lógica de fecha real
        matricula = Matricula(id_matricula, fecha_matricula, alumno.id, curso.id)
        self.matriculas.append(matricula)
        print_color(f"{alumno.nombre} se ha matriculado en el curso {curso.nombre}.", Colores.AMARILLO)
        print()

    def mostrar_matriculas(self):
        print_color("Matrículas realizadas en el centro:", Colores.CYAN)
        for matricula in self.matriculas:
            matricula.mostrar_datos()


class MenuCentroEstudios:
    def __init__(self, centro_estudios):
        self.centro_estudios = centro_estudios

    def mostrar_menu(self):
        opciones = [
            "Mostrar ficha del curso",
            "Mostrar ficha del alumno",
            "Matricular alumno en un curso",
            "Mostrar datos de matrícula",
            "Mostrar matrículas realizadas en el centro",
            "Salir"
        ]

        for i, opcion in enumerate(opciones):
            print_color(f"{i + 1}. {opcion}", Colores.VERDE)

    def ejecutar_opcion(self, opcion):
        if opcion == "6":
            print_color("Saliendo del programa. ¡Hasta luego!", Colores.ROJO)
            return False
        elif opcion == "1" or opcion == "2":
            getattr(self.centro_estudios, f"curso{opcion}").mostrar_ficha()
        elif opcion == "3":
            id_curso = input("Ingresa el ID del curso: ")
            curso_seleccionado = self.centro_estudios.curso1 if id_curso == "1" else self.centro_estudios.curso2
            self.centro_estudios.matricular_alumno(self.centro_estudios.alumno1, curso_seleccionado)
        elif opcion == "4":
            self.centro_estudios.mostrar_matriculas()
        elif opcion == "5":
            id_curso = input("Ingresa el ID del curso: ")
            curso_seleccionado = self.centro_estudios.curso1 if id_curso == "1" else self.centro_estudios.curso2
            curso_seleccionado.mostrar_ficha()
        else:
            print_color("Opción no válida. Por favor, selecciona una opción del menú.", Colores.ROJO)
        return True


centro = CentroEstudios()
menu = MenuCentroEstudios(centro)

while True:
    menu.mostrar_menu()
    opcion = input("Selecciona una opción (Selecciona una opción (1-6): ")
    print("\n" + "=" * 40 + "\n")
    if not menu.ejecutar_opcion(opcion):
        break
